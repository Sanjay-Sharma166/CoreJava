package com.yash.ems.exception;

public class EmployeeIdNotFoundException  extends Exception
{
	public EmployeeIdNotFoundException(String msg) 
	{
		super(msg);
	}

	
}

package com.yash.ems.exception;

public class EmployeeByNameNotFoundException extends Exception 
{
	 public EmployeeByNameNotFoundException(String msg) 
		  {
			  super(msg);
		  }
}

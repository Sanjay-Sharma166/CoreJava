package com.yash.ems.exception;

public class EmployeeBySalaryNotFoundException extends Exception
{
	 public EmployeeBySalaryNotFoundException(String msg)
	  {
		  super(msg);
	  }
}

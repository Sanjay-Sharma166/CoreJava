package com.yash.ems.util;

public class Constant {

	private Constant()
	{}
	
	public static final String STR_EMPTY  = "";
	public static final String STR_COMP_NAME  = "Yash Technologies";
	public static final String STR_1  = "1";
	public static final String STR_2  = "2";
	public static final String STR_3  = "3";
	public static final String STR_4  = "4";
	public static final String STR_5  = "5";
	public static final String STR_0  = "0";
}
